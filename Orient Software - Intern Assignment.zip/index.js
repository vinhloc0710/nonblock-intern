var input =[
    {
        id: 1,
        startTime:180,
        endTime:220
    },

    {
        id: 2,
        startTime:0,
        endTime:120
    },

    {
        id: 3,
        startTime:110,
        endTime:150
    }
]
function findSlot(input, value){
    let sortArr = input.sort((a, b) =>{
        if(a.startTime < b.startTime) return -1;
        return 1;
    })

    var start = 0;
    var end = value;
    let isAvailable = false;

    sortArr.forEach( element=> {
        if(end > element.startTime && !isAvailable) {
            start = element.endTime;
            end = element.endTime + value
        } else if(!isAvailable){
            isAvailable = true;
        }
    })
    return {start: start, end: end}
}
console.log(findSlot(input, 30))